# M3 one-elevator rider checkpoint — 2026-09-10

**Status:** T054–T063 implementation and automated checks pass. **T064 remains unchecked.** The Mac was locked and native app automation was unavailable. Actual stable Chrome/Firefox/Safari M3 qualification did not run.

Supplemental checks used the production-mode `dist-browser-test/` at `http://127.0.0.1:4174/` in the Codex in-app browser with seed `00000001000000020000000300000004`. The one-worker office fixture leaves standard car capacity at eight and retains all default movement/service durations. Native browser version is unavailable; these observations do not qualify native browsers.

- Loaded **One worker — upper office needing elevator**. At paused 06:00, selected Elevator and previewed cell 18, floors 0–3. Price was $2,200. Ordinary commitment changed cash from $9,256 to $7,056; Canvas showed an aligned shaft, four landings and the car at ground.
- A floor inspection showed that the upper floor became accessible through walking and vertical transport, with the shaft's two-cell reservation excluded from free construction space.
- Loaded **One elevator rider — paused mid-flight**. Selected the shaft using **Selected connection**. Inspector showed `shaft:8`, `car:10`, serving 0–3, moving upward at floor 0.00 with **Load 1/8** and zero queues at all four floors. Repeated paused inspection left position, load and costs unchanged.
- Attempted ordinary loaded removal: “Unload all passengers before removing this shaft.” Attempted service shrink to 0–2: “The loaded car must retain every committed unloading stop.” Both left the loaded car and served range intact.
- Resumed Normal then paused. The inspector showed the now-empty car idle at floor 3, **Load 0/8**, with current accrued operating cost. This establishes the observed before/after state; tool latency did not permit continuous observation of every one-second passenger phase.
- Loaded **One elevator rider — paused boarding** after rebuilding. The inspector showed boarding, floor 0.00, **Load 0/8**, and **F0 up queue 1**. This confirms the selected passenger remains queued until transfer completion.
- No errors or warnings were returned by the in-app console-log check during the initial selection investigation. The narrow-shaft pointer check was inconclusive in this automation surface; the labeled selector and subsequent actions were verified.

Automated tests exercise every car phase, the 2→3→5 sweep, idle ties, no mid-floor reversal, empty canceled reposition, immutable origin-mode preference, no queue-only stairs fallback, walking to a real request anchor, timed atomic transfers, unload commitments, phase snapshots, strict rejection of malformed transport data, service edits during travel, idle cost settlement and equal following-day outcomes after capture/rebuild. The focused [timing sample](../../../docs/performance/single-elevator.md) is headless evidence only.

Full continuous M3 observation and pause/resume at every phase in actual stable Chrome, Firefox and Safari remain pending. Artifact identities are in [phase-6-7-artifacts.json](../../../docs/phase-6-7-artifacts.json). Earlier visual checks are supplemental to the final small pointer-input refinements; no native release qualification is claimed.
