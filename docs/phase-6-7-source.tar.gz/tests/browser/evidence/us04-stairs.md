# C1 stair checkpoint — 2026-09-10

**Status:** T048–T052 implementation and automated checks pass. **T053 remains unchecked.** Native apps could not be accessed because the Mac was locked, so actual stable Chrome/Firefox/Safari C1 qualification did not run.

Supplemental observations used the production-mode `dist-browser-test/` at `http://127.0.0.1:4174/` in the Codex in-app browser. Seed: `00000001000000020000000300000004`; one-worker fixtures keep production travel timings. Native browser version is unavailable, and this in-app surface does not substitute for the required browsers.

- Started **One worker — upper office needing stairs** at day 1, 06:00. Selected ordinary Stairs controls and previewed lower floor 0, cell 10: valid connection, $50.
- Committed through **Build connection**. Cash changed from $9,352 to $9,302, and the stair connection became selectable. Its inspector described floors 0–1, zero recurring cost and the occupied-removal guard.
- Used **Selected connection** to select the unoccupied stair and remove it. The UI reported that access was updated; cash stayed $9,302, consistent with free demolition and no refund.
- Loaded **One worker — paused on stairs**, a domain-generated valid state at 09:15, through the fixture chooser. The Canvas showed the stair and worker at its lower end. Attempted ordinary removal while paused: “A person is using these stairs. Wait for them to reach the landing.” The worker, stair and clock stayed in place.
- The tower remains visible alongside scrolled transport controls. Narrow connections can be selected using the labeled selector.

Automated tests cover two-way nonzero traversal, full landing reservations, atomic prices/failures, office leasing/attendance, no double movement, pause, occupied removal, abandoned unreachable visits, valid-segment completion, stranded exits, repair and capture/rebuild with a pending replan. They also close the US4 elevator preference/fallback clauses through real elevator integration.

Continuous browser observation of a full climb, descent and stranded-exit repair in all three native browsers remains pending. Static-build outcomes and final artifact/source hashes are recorded in [phase-6-7-artifacts.json](../../../docs/phase-6-7-artifacts.json). Early construction/occupied-removal observations preceded the final Canvas input refinements and are supplemental; no full final-artifact native qualification is claimed.
